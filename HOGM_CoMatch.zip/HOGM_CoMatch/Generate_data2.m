function [Data1,Data2]=Generate_data2(file_path,source)
%% Read data

fN1=[source,'D1.csv'];
fN2=[source,'D2.csv'];

GE=readtable(fN1,'ReadRowNames',true);
AUC=readtable(fN2,'ReadRowNames',true);
Data1=GE{:,:};
Data2=AUC{:,:};

%show figure
figure(1)
imagesc(Data1)
%colorbar
str1=[file_path,'D1.jpg'];
saveas(gcf,str1);
clear val

%show figure
figure(2)
imagesc(Data2)
%colorbar
str2=[file_path,'D2.jpg'];
saveas(gcf,str2);


