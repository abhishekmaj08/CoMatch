
clear all; close all; clc;
savePath='result';
source='input/';
do_experiment_with_synthetic(savePath,source);
