fN1='/Users/maju06/Documents/OSUMC/CoMatch/CoMatch_SyntheticData/S1.csv';
fN2='/Users/maju06/Documents/OSUMC/CoMatch/CoMatch_SyntheticData/S2.csv';

GE=readtable(fN1,'ReadRowNames',true);
AUC=readtable(fN2,'ReadRowNames',true);
Data1=GE{:,:};
Data2=AUC{:,:};

fNl1='/Users/maju06/Documents/OSUMC/CoMatch/CoMatch_SyntheticData/prelabel1.csv';
fNl2='/Users/maju06/Documents/OSUMC/CoMatch/CoMatch_SyntheticData/prelabel2.csv';
pre1=readtable(fNl1,'ReadRowNames',true);
pre2=readtable(fNl2,'ReadRowNames',true);
prelabel1=pre1{:,:};
prelabel2=pre2{:,:};

cnum = 2;
[denominator ignore] = size(prelabel1);

hogm_t1=readtable("/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/X_HOG.csv");
% hogm_t1 is already in y_featuresXx_features. we need the transpose of it
hogm=hogm_t1{:,:};

[tmp1 match_hogm] = max(hogm);

afterlabel_hogm=prelabel2(match_hogm);
c_hogm=confusionmat(prelabel1,afterlabel_hogm);

c_hogm

temp_hogm=0;
for j=1:cnum
     temp_hogm=temp_hogm+c_hogm(j,j);
end
accuracy_hogm=temp_hogm/denominator;
accuracy_hogm

imagesc(hogm');
colorbar
str2=['/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/','hogm.jpg'];
saveas(gcf,str2);

plsca_t1=readtable("/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/plsca1.csv");
plsca_t2=plsca_t1{:,:};
% needed as plsca_t2 is x_featuresXy_features. we need the transpose of it
plsca=plsca_t2';

[tmp1 match_plsca] = max(plsca);

afterlabel_plsca=prelabel2(match_plsca);
c_plsca=confusionmat(prelabel1,afterlabel_plsca);

c_plsca

temp_plsca=0;
for j=1:cnum
     temp_plsca=temp_plsca+c_plsca(j,j);
end
accuracy_plsca=temp_plsca/denominator;
accuracy_plsca

imagesc(plsca');
colorbar
str2=['/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/','plsca.jpg'];
saveas(gcf,str2);

cca_t1=readtable("/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/cca1.csv");
cca_t2=cca_t1{:,:};
% needed as cca_t2 is x_featuresXy_features. we need the transpose of it
cca=cca_t2';

[tmp1 match_cca] = max(cca);

afterlabel_cca=prelabel2(match_cca);
c_cca=confusionmat(prelabel1,afterlabel_cca);

c_cca

temp_cca=0;
for j=1:cnum
     temp_cca=temp_cca+c_cca(j,j);
end
accuracy_cca=temp_cca/denominator;
accuracy_cca

imagesc(cca');
colorbar
str2=['/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/','cca.jpg'];
saveas(gcf,str2);

plsr_t1=readtable("/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/plsr1.csv");
plsr_t2=plsr_t1{:,:};
% needed as plsr_t2 is x_featuresXy_features. we need the transpose of it
plsr=plsr_t2';

[tmp1 match_plsr] = max(plsr);

afterlabel_plsr=prelabel2(match_plsr);
c_plsr=confusionmat(prelabel1,afterlabel_plsr);

c_plsr

temp_plsr=0;
for j=1:cnum
     temp_plsr=temp_plsr+c_plsr(j,j);
end
accuracy_plsr=temp_plsr/denominator;
accuracy_plsr

imagesc(plsr');
colorbar
str2=['/Users/maju06/Documents/OSUMC/CoMatch/Version09262022/methods_comparison/','plsr.jpg'];
saveas(gcf,str2);




