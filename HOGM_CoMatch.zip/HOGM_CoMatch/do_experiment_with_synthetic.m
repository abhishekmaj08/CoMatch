function  do_experiment_with_synthetic(savePath,source)

mkdir (savePath);
file_path=[savePath,'/'];
    
[Data1,Data2]=Generate_data2(file_path,source);
[n1,nF1]=size(Data1);
[n2,nF2]=size(Data2);
[indPT1,valPT1,indPM1]=produce_random_prior_D1(n1,n2,nF1,nF2,file_path);
[indPT2,valPT2,indPM2]=produce_random_prior_D2(n1,n2,nF1,nF2,file_path);
[prior_X]=produce_random_prior_D12(n1,n2,nF1,nF2,file_path);
do_HOGMMNC(Data1,Data2,indPT1,valPT1,indPT2,valPT2,prior_X,file_path);

     

end

