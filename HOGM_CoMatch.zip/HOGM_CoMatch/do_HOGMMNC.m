function do_HOGMMNC(Data1,Data2,indPT1,valPT1,indPT2,valPT2,prior_X,file_path)
%% insert matlab toolbox
addpath('ann_mwrapper');
addpath('mex');
%% Generate data
%data
P1=Data1;
P2=Data2;
[n1,nF1]=size(Data1);
[n2,nF2]=size(Data2);
lambda=[0.2;0.4];
%% 3rd Order Tensor
flag=2;
[t1,t2,nT1,nT2] = Generate_tuples(P1,P2,nF1,nF2,flag);%1:Oliver,2:ours,3:ochs

%generate features
t1=int32(t1);
t2=int32(t2);
[feat11,feat22] = mexComputeFeature_angle_distance_sample(P1,P2,int32(t1),int32(t2),'simple');
feat1=feat11(1:3,:);%angle information
feat2=feat22(1:3,:);%angle information
% feat1=feat11(4:6,:);%distance information
% feat2=feat22(4:6,:);%distance information
%number of nearest neighbors used for each triangle (results can be bad if too low)
nNN=1000;

%find the nearest neighbors
clear inds
[inds, dists] = annquery(feat2, feat1, nNN, 'eps', 10);

%build the tensor
tmp=repmat(1:nT1,nNN,1);
inds=int32(inds);
indH3 = t1(:,tmp(:))'*nF2 + t2(:,inds(:))';
valH3 = exp(-dists(:)/mean(dists(:)));

%initiatialize X
X=1/nF2*ones(nF2,nF1);
[rows,cols]=find(prior_X>0);
for i=1:size(rows)
    X(rows(i),cols(i))=1;
end
%power iteration
[X_ours, score]=tensorMatching_prior_alpha(X,[],[],[],[],indH3,valH3,indPT1,valPT1,indPT2,valPT2,200,1,2,lambda);


figure(3);
imagesc(X_ours');
colorbar
str2=[file_path,'X_HOGM.jpg'];
saveas(gcf,str2);
str3=[file_path,'X_HOGM.csv'];
writematrix(X_ours,str3); 








